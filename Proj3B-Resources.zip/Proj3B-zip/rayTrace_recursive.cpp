#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS // For fopen and sscanf
#define _USE_MATH_DEFINES 
#endif

//Images Lib includes:
#define STB_IMAGE_IMPLEMENTATION //only place once in one .cpp file
#define STB_IMAGE_WRITE_IMPLEMENTATION //only place once in one .cpp files
#include "image_lib.h" //Defines an image class and a color class

//#Vec3 Library
#include "vec3.h"

//High resolution timer
#include <chrono>
#include <omp.h>
#include <iomanip>
#include <algorithm>

//Scene file parser
#include "parse_vec3.h"


bool raySphereIntersect(vec3 start, vec3 dir, vec3 center, float radius, float &tHit){
  float a = dot(dir,dir);
  vec3 toStart = (start - center);
  float b = 2 * dot(dir,toStart);
  float c = dot(toStart,toStart) - radius*radius;
  float discr = b*b - 4*a*c;
  if (discr < 0) return false;
  float sqrtDiscr = sqrt(discr);
  float t0 = (-b - sqrtDiscr) / (2 * a);
  float t1 = (-b + sqrtDiscr) / (2 * a);
  
  if (t0 > 0 && t1 > 0) tHit = std::min(t0, t1);
  else if (t0 > 0) tHit = t0;
  else if (t1 > 0) tHit = t1;
  else return false;
  return true;
}

bool rayTriIntersect(vec3 start, vec3 dir, vec3 p1, vec3 p2, vec3 p3, float &tHit){
    float e = 1e-9f;
    vec3 edge1 = p2-p1;
    vec3 edge2 = p3-p1;
    vec3 ray_cross_edge2 = cross(dir, edge2);
    float d = dot(edge1, ray_cross_edge2);

    if(d > -e && d < e){
        return false;
    }
    float r_d = 1.0f / d;

    vec3 s = start - p1;
    float u = r_d * dot(s, ray_cross_edge2);

    if((u < 0 && std::abs(u) > e) || (u > 1 && std::abs(u-1) > e)){
        return false;
    }

    vec3 s_cross_edge1 = cross(s, edge1);
    float v = r_d * dot(dir, s_cross_edge1);

    if ((v < 0 && std::abs(v) > e) || (u + v > 1 && std::abs(u + v - 1) > e)){
        return false;
    }

    float t = r_d * dot(edge2, s_cross_edge1);

    if (t > e){
        tHit = t;
        return true;
    }
    else {
        return false;
    }

}

vec3 rayTrace(vec3 start, vec3 dir, int depth=5){
	if (depth <= 0) {
	    return backgroundColor;
	}
	float closestT = std::numeric_limits<float>::max();
    int hitSphereIndex = -1;
    int hitTriangleIndex = -1;
    
    for (int s = 0; s < spheres.size(); s++) {
        float tHit;
        if (raySphereIntersect(start, dir, spheres[s].pos, spheres[s].rad, tHit)) {
            if (tHit < closestT) {
                closestT = tHit;
                hitSphereIndex = s;
            }
        }
    }
    for(int t = 0; t<triangles.size(); t++){
        float tHit;
        if (rayTriIntersect(start, dir, triangles[t].p1, triangles[t].p2, triangles[t].p3, tHit)) {
            if (tHit < closestT) {
                closestT = tHit;
                hitTriangleIndex = t;
            }
        }
    }

      if (hitSphereIndex != -1){
        Sphere &sphere = spheres[hitSphereIndex];

        vec3 hitPoint = start + closestT*dir;
        vec3 normal = (hitPoint - sphere.pos).normalized();

        vec3 Ia = sphere.mat.ka * ambientLight;
        vec3 Id(0, 0, 0);
        vec3 Is(0, 0, 0);
        vec3 V = (start - hitPoint).normalized();

        
        for (const auto& light : lights) {
            vec3 L;
            float attenuation = 1.0f;
            float lightDist = INFINITY;
            bool inShadow = false;
            if(light.type == LightType::POINT){
                L = (light.pos - hitPoint).normalized();
                float lightDist = (light.pos - hitPoint).length();
                attenuation = 1.0f / (lightDist* lightDist);        
            }else if(light.type == LightType::DIR){
                L = (-light.dir).normalized();
            }else if (light.type == LightType::SPOT) {
                vec3 LtoP = (hitPoint - light.pos).normalized();
                L = -LtoP;
                lightDist = (light.pos - hitPoint).length();
            
                float spotCos = dot(LtoP, light.dir.normalized());
        
                float cos1 = std::cos(light.angle1 * M_PI / 180.0f);
                float cos2 = std::cos(light.angle2 * M_PI / 180.0f);
            
                if (spotCos < cos2) {
                    continue; 
                } else if (spotCos > cos1) {
                    attenuation = 1.0f / (lightDist * lightDist);
                } else {
                    float t = (spotCos - cos2) / (cos1 - cos2);
                    attenuation = t / (lightDist * lightDist);
                }
            }
            for (int s = 0; s < spheres.size(); s++) {
                float tHit;
                if (raySphereIntersect(hitPoint + 1e-4f * L, L, spheres[s].pos, spheres[s].rad, tHit)) {
                    if (tHit < lightDist) {
                        inShadow = true;
                        break;
                    }
                }
            }
            for (int t = 0; t < triangles.size(); t++) {
                float tHit;
                if (rayTriIntersect(hitPoint + 1e-4f * L, L, triangles[t].p1, triangles[t].p2, triangles[t].p3, tHit)) {
                    if (tHit < lightDist) { inShadow = true; break; }
                }
            }
            if (!inShadow) {
                vec3 R = (2.0f * dot(normal, L) * normal - L).normalized();
                Id += attenuation * std::max(0.0f, dot(normal, L)) * light.col * sphere.mat.kd;
                if (sphere.mat.ks.length() > 0.0f){
                    Is += vec3(0.0f,0.0f,0.0f);
                }else{
                    Is += attenuation * std::pow(std::max(0.0f, dot(R, V)), sphere.mat.shininess) * light.col * sphere.mat.ks;
                }
            }
        }



        vec3 c = Ia + Id + Is;
        vec3 reflectionColor(0, 0, 0);
		if (depth > 0) {
		    vec3 reflectDir = (dir - (2.0f * dot(dir, normal) * normal) ).normalized();
		    reflectionColor = rayTrace(hitPoint + 1e-4f * reflectDir, reflectDir, depth - 1);
		}
		
        

        vec3 refractionColor(0,0,0);
        bool didTIR = false;
        if(sphere.mat.kt.length() > 0.0f){
            vec3 N = normal;
            float eta;
            float cosi = dot(dir, normal);
            bool entering = cosi < 0;
            if(entering){
                eta = 1.0f / sphere.mat.ior;
                cosi = -cosi;
            }else {
                eta = sphere.mat.ior;
                N = -1 * N;
            }

            float k = 1.0f - eta * eta * (1.0f - cosi * cosi);
            if(k >= 0.0f){
                vec3 refractDir = (eta * dir + (eta * cosi - std::sqrt(k)) * N).normalized();
                refractionColor = rayTrace(hitPoint + 1e-4f * refractDir, refractDir, depth -1);
            }else {
                didTIR = true;

            }
        }

        vec3 refract = sphere.mat.kt * refractionColor;
        vec3 reflect =  sphere.mat.ks * reflectionColor;
        vec3 ks = sphere.mat.ks;
        vec3 kt = sphere.mat.kt;
        if (didTIR) {
            ks = ks + kt;
            kt = vec3(0.0f,0.0f,0.0f);
        }
        reflect =  ks * reflectionColor;
        refract = kt * refractionColor;
        

        vec3 c_final = (vec3(1.0f,1.0f,1.0f) - ks - kt).clampTo1() * c + reflect + refract;        // vec3 c_final = (vec3(1.0f,1.0f,1.0f) - sphere.mat.ks).clampTo1() * c + reflect;

        vec3 c_clamped = c_final.clampTo1();

        return c_clamped;
    }
    if (hitTriangleIndex != -1) {
        Triangle &tri = triangles[hitTriangleIndex];
        vec3 hitPoint = start + closestT * dir;

        // Compute normal
        vec3 edge1 = tri.p2 - tri.p1;
        vec3 edge2 = tri.p3 - tri.p1;
        vec3 normal = cross(edge1, edge2).normalized();
        if(tri.hasNormals){
            vec3 h_p = hitPoint- tri.p1;
            float d00 = dot(edge1, edge1);
            float d01 = dot(edge1, edge2);
            float d11 = dot(edge2, edge2);
            float d20 = dot(h_p, edge1);
            float d21 = dot(h_p, edge2);

            float denom = d00 * d11 - d01 * d01;
            float beta = (d11 * d20 - d01 * d21) / denom; 
            float gamma = (d00 * d21 - d01 * d20) / denom; 
            float alpha = 1.0f - beta - gamma; 
            normal = (alpha*tri.n1 + beta*tri.n2 + gamma*tri.n3).normalized();
        }

        vec3 Ia = tri.mat.ka * ambientLight;
        vec3 Id(0, 0, 0);
        vec3 Is(0, 0, 0);
        vec3 V = (start - hitPoint).normalized();

        
        for (const auto& light : lights) {
            vec3 L;
            float attenuation = 1.0f;
            float lightDist = INFINITY;
            bool inShadow = false;
            if(light.type == LightType::POINT){
                L = (light.pos - hitPoint).normalized();
                lightDist = (light.pos - hitPoint).length();
                attenuation = 1.0f / (lightDist * lightDist);
            }else if(light.type == LightType::DIR){
                L = (-light.dir).normalized();
            }else if (light.type == LightType::SPOT) {
                vec3 LtoP = (hitPoint - light.pos).normalized();
                L = -LtoP;
                lightDist = (light.pos - hitPoint).length();
                

                float spotCos = dot(L, light.dir.normalized());
                
                float cos1 = std::cos(light.angle1 * M_PI / 180.0f);
                float cos2 = std::cos(light.angle2 * M_PI / 180.0f);

                if (spotCos < cos2) continue;

                float t = std::clamp((spotCos - cos2) / (cos1 - cos2), 0.0f, 1.0f);
                attenuation = t / (lightDist * lightDist);
            }
            for (int s = 0; s < spheres.size(); s++) {
                    float tHit;
                    if (raySphereIntersect(hitPoint + 1e-4f * L, L, spheres[s].pos, spheres[s].rad, tHit)) {
                        if (tHit < lightDist) {
                            inShadow = true;
                            break;
                        }
                    }
                }
            for (int t = 0; t < triangles.size(); t++) {
                float tHit;
                if (rayTriIntersect(hitPoint + 1e-4f * L, L, triangles[t].p1, triangles[t].p2, triangles[t].p3, tHit)) {
                    if (tHit < lightDist) { inShadow = true; break; }
                }
            }
            if (!inShadow) {
                
                vec3 R = (2.0f * dot(normal, L) * normal - L).normalized();
                Id += attenuation * std::max(0.0f, dot(normal, L)) * light.col * tri.mat.kd;
                if (tri.mat.ks.length() > 0.0f){
                    Is += vec3(0.0f,0.0f,0.0f);
                }else{
                    Is += attenuation * std::pow(std::max(0.0f, dot(R, V)), tri.mat.shininess) * light.col * tri.mat.ks;
                }
            }
        }



        vec3 c = Ia + Id + Is;
        vec3 reflectionColor(0, 0, 0);
        if (depth > 0) {
            vec3 reflectDir = (dir - (2.0f * dot(dir, normal) * normal) ).normalized();
            reflectionColor = rayTrace(hitPoint + 1e-4f * reflectDir, reflectDir, depth - 1);
        }
        
        

        vec3 refractionColor(0,0,0);
        bool didTIR = false;
        if(tri.mat.kt.length() > 0.0f){
            vec3 N = normal;
            float eta;
            float cosi = dot(dir, normal);
            bool entering = cosi < 0;
            if(entering){
                eta = 1.0f / tri.mat.ior;
                cosi = -cosi;
            }else {
                eta = tri.mat.ior;
                N = -1 * N;
            }

            float k = 1.0f - eta * eta * (1.0f - cosi * cosi);
            if(k >= 0.0f){
                vec3 refractDir = (eta * dir + (eta * cosi - std::sqrt(k)) * N).normalized();
                refractionColor = rayTrace(hitPoint + 1e-4f * refractDir, refractDir, depth -1);
            }else {
                didTIR = true;

            }
        }

        vec3 refract = tri.mat.kt * refractionColor;
        vec3 reflect =  tri.mat.ks * reflectionColor;
        vec3 ks = tri.mat.ks;
        vec3 kt = tri.mat.kt;
        if (didTIR) {
            ks = ks + kt;
            kt = vec3(0.0f,0.0f,0.0f);
        }
        reflect =  ks * reflectionColor;
        refract = kt * refractionColor;
        

        vec3 c_final = (vec3(1.0f,1.0f,1.0f) - ks - kt).clampTo1() * c + reflect + refract;        // vec3 c_final = (vec3(1.0f,1.0f,1.0f) - sphere.mat.ks).clampTo1() * c + reflect;

        vec3 c_clamped = c_final.clampTo1();

        return c_clamped;
    }
    return backgroundColor;
    
}

int main(int argc, char** argv){

  //Read command line paramaters to get scene file
  if (argc != 2){
     std::cout << "Usage: ./ray scenefile\n";
     return(0);
  }
  std::string sceneFileName = argv[1];

  //Parse Scene File
  parseSceneFile(sceneFileName);


  float imgW = img_width, imgH = img_height;
  float halfW = imgW/2, halfH = imgH/2;
  float d = halfH / tanf(halfAngleVFOV * (M_PI / 180.0f));

  Image outputImg = Image(img_width,img_height);
  auto t_start = std::chrono::high_resolution_clock::now();
    int lastPercent = -1;
    // #pragma omp parallel for schedule(dynamic) num_threads(2)
    #pragma omp parallel for schedule(dynamic)
    for (int i = 0; i < img_width; i++) {
        for (int j = 0; j < img_height; j++) {
            float u = (halfW - (imgW) * ((i + 0.5f) / imgW));
            float v = (halfH - (imgH) * ((j + 0.5f) / imgH));
            vec3 p = eye - d * forward + u * right + v * up;
            vec3 rayDir = (p - eye).normalized();
            vec3 c = rayTrace(eye, rayDir, max_depth);
            Color color = Color(c.x, c.y, c.z);
            outputImg.setPixel(i, j, color);
        }
        float progress = (float)(i + 1) / (float)img_width;
        int percent = static_cast<int>(progress * 100.0f);
        // Progress bar update (only one thread prints)
        #pragma omp critical
        {
            if (percent > lastPercent) {
            lastPercent = percent;

            int barWidth = 50;
            int pos = static_cast<int>(barWidth * progress);

            std::cout << "\r[";
            for (int j = 0; j < barWidth; ++j) {
                if (j < pos) std::cout << "#";
                else std::cout << " ";
            }
            std::cout << "] " << std::fixed << std::setprecision(1)
                      << (progress * 100.0f) << "%";
            std::cout.flush();
        }
        }
    }
    auto t_end = std::chrono::high_resolution_clock::now();
    std::cout << "\nRendering took "
            << std::fixed << std::setprecision(2)
            << std::chrono::duration<double, std::milli>(t_end - t_start).count()
            << " ms" << std::endl;
    outputImg.write(imgName.c_str());
    return 0;
}
