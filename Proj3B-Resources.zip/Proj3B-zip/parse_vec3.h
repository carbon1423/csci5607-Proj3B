
//Set the global scene parameter variables
//TODO: Set the scene parameters based on the values in the scene file

#ifndef PARSE_VEC3_H
#define PARSE_VEC3_H

#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstring>
#include <sstream>
#include <vector>

//Camera & Scene Parameters (Global Variables)
//Here we set default values, override them in parseSceneFile()

#define MAX_VERTICES 10000
#define MAX_NORMALS 10000


struct Material {
    vec3 ka; 
    vec3 kd; 
    vec3 ks; 
    vec3 kt; 
    float shininess; 
    float ior;        
    Material(vec3 a, vec3 d, vec3 s, vec3 t, float shine, float i) : ka(a), kd(d), ks(s), kt(t), shininess(shine), ior(i) {}
};
struct Sphere {
  vec3 pos;
  float rad;
  Material mat;
  Sphere(vec3 p, float r, Material m) : pos(p), rad(r), mat(m){}
};
struct Triangle {
   vec3 p1,p2,p3,n1,n2,n3;
   bool hasNormals = false;
   Material mat;
   Triangle(vec3 a, vec3 b, vec3 c, Material m) : p1(a), p2(b), p3(c), mat(m){}
   Triangle(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e, vec3 f, Material m) : p1(a), p2(b), p3(c),n1(d), n2(e), n3(f), mat(m){
    hasNormals = true;
   }
};
enum class LightType { POINT, DIR, SPOT };

struct Light{
  LightType type;
  vec3 pos;
  vec3 dir;
  vec3 col;
  float angle1;
  float angle2;
  Light(vec3 p, vec3 c, LightType t) : col(c), type(t){
    if(t == LightType::POINT){
      pos = p;
    }else if(t== LightType::DIR){
      dir = p;
    }
  }
   //point and dir
  Light(vec3 p, vec3 c, vec3 d, float a1, float a2, LightType t) : pos(p), col(c), dir(d), angle1(a1), angle2(a2), type(t){} //spot
};


//Image Parameters
int img_width = 800, img_height = 600;
std::string imgName = "raytraced.png";

//Camera Parameters
vec3 eye = vec3(0,0,0); 
vec3 forward = vec3(0,0,-1).normalized();
vec3 up = vec3(0,1,0).normalized();
vec3 right;
float halfAngleVFOV = 35; 

//Scene (Sphere) Parameters
std::vector<Sphere> spheres;

int max_vert;
int max_norm;
int vert_i = 0;
int norm_i = 0;
std::vector<vec3> vertices;
std::vector<vec3> normals;
std::vector<Triangle> triangles;

//Lighting 
std::vector<Light> lights;
vec3 ambientLight = vec3(0,0,0);

//Background
vec3 backgroundColor = vec3(0,0,0);

int max_depth = 5;



void parseSceneFile(std::string fileName){
  //TODO: Override the default values with new data from the file "fileName"
  std::ifstream file(fileName);
  std::string line;
  Material currentMaterial(
        vec3(0,0,0), vec3(1,1,1), vec3(0,0,0), vec3(0,0,0), 5.0f, 1.0f
        );
  while (getline(file, line)){
    std::string chunk;
    std::stringstream ss(line);
    while(ss >> chunk){
      if(chunk.compare("material:") == 0){
        float ar, ag, ab,
              dr, dg, db,
              sr, sg, sb, ns,
              tr, tg, tb, ior;
        ss >> ar >> ag >> ab >> 
              dr >> dg >> db >> 
              sr >> sg >> sb >> ns >>
              tr >> tg >> tb >> ior;
        currentMaterial = Material(vec3(ar,ag,ab), 
                            vec3(dr,dg,db), 
                            vec3(sr,sg,sb),
                            vec3(tr,tg,tb), ns, ior);
      }
      if(chunk.compare("sphere:") == 0){
        float x,y,z,r; 
        ss >> x >> y >> z >> r;
        spheres.push_back(Sphere(vec3(x,y,z), r, currentMaterial));
      }
      
      if(chunk.compare("image_resolution:") == 0){
        int w,h;
        ss >> w >> h;
        img_width = w;
        img_height = h;
      }
      if(chunk.compare("film_resolution:") == 0){
        int w,h;
        ss >> w >> h;
        img_width = w;
        img_height = h;
      }

      if(chunk.compare("output_image:") == 0){
        std::string outName;
        ss >> outName;
        imgName = outName;
      }
      if(chunk.compare("camera_pos:") == 0){
        float x,y,z;
        ss >> x >> y >> z;
        eye = vec3(x,y,z);
      }
      if(chunk.compare("camera_up:") == 0){
        float ux, uy, uz;
        ss >> ux >> uy >> uz;
        up = vec3(ux, uy, uz).normalized();
      }
      if(chunk.compare("camera_fwd:") == 0){
        float fx, fy, fz;
        ss >> fx >> fy >> fz;
        forward = vec3(fx, fy, fz).normalized();
      }
      if(chunk.compare("camera_fov_ha:") == 0){
        float ha;
        ss >> ha;
        halfAngleVFOV = ha;
      }
      if(chunk.compare("background:") == 0){
        float r, g, b;
        ss >> r >> g >> b;
        backgroundColor = vec3(r,g,b);
      }
      if(chunk.compare("point_light:") == 0){
        float r, g, b, x, y, z;
        ss >> r >> g >> b >> x >> y >> z;
        vec3 lightColor = vec3(r,g,b);
        vec3 lightPos = vec3(x,y,z);
        LightType type = LightType::POINT;
        lights.push_back(Light(lightPos, lightColor, type));
      }
      if(chunk.compare("directional_light:") == 0){
        float r, g, b, x, y, z;
        ss >> r >> g >> b >> x >> y >> z;
        vec3 lightColor = vec3(r,g,b);
        vec3 lightDir = vec3(x,y,z);
        LightType type = LightType::DIR;
        lights.push_back(Light(lightDir, lightColor, type));
      }
      if(chunk.compare("spot_light:") == 0){
        float r, g, b, px, py, pz, dx, dy, dz, a1, a2;
        ss >> r >> g >> b >> px >> py >> pz >> dx >> dy >> dz >> a1 >> a2;
        vec3 lightColor = vec3(r,g,b);
        vec3 lightPos = vec3(px,py,pz);
        vec3 lightDir = vec3(dx,dy,dz);
        LightType type = LightType::SPOT;
        lights.push_back(Light(lightPos, lightColor, lightDir, a1, a2, type));
        // std::cout << "spot light" << r << g << b << px << py << pz << dx << dy << dz << a1 << a2 << std::endl;
      }
      if(chunk.compare("ambient_light:") == 0){
        float r, g, b;
        ss >> r >> g >> b;
        ambientLight = vec3(r,g,b);
      }
      if(chunk.compare("max_depth") == 0){
        int n;
        ss >> n;
        max_depth = n;
      }
      if(chunk.compare("max_vertices:") == 0){
        int n;
        ss >> n;
        max_vert = n;
      }
      if(chunk.compare("max_normals:") == 0){
        int n;
        ss >> n;
        max_norm = n;
      }
      if(chunk.compare("vertex:") == 0 && max_vert > 0 && vert_i < max_vert){
        float x,y,z;
        ss >> x >> y >> z;

        vertices.push_back(vec3(x,y,z));
        vert_i += 1;
      }
      if(chunk.compare("normal:") == 0 && max_norm > 0 && norm_i < max_norm){
        float x,y,z;
        ss >> x >> y >> z;

        normals.push_back(vec3(x,y,z));
        norm_i += 1;
      }
      if(chunk.compare("triangle:") == 0){
        int v1,v2,v3;
        ss >> v1 >> v2 >> v3;
        triangles.push_back(Triangle(vertices[v1], vertices[v2], vertices[v3], currentMaterial));
      }
      if(chunk.compare("normal_triangle:") == 0){
        int v1,v2,v3,n1,n2,n3;
        ss >> v1 >> v2 >> v3 >> n1 >> n2 >> n3;
        triangles.push_back(Triangle(vertices[v1], vertices[v2], vertices[v3], normals[n1], normals[n2], normals[n3], currentMaterial));
      }
    }
  }

  right = cross(up, forward).normalized();

}

#endif